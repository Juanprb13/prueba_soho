import express from "express";
import mongoose from "mongoose";
import Proyect from "./models/proyects.js";

const app = express();

mongoose.connect(
    "mongodb+srv://juan:1234567890a@cluster0.sxff1.mongodb.net/soho?retryWrites=true&w=majority",
    {
        useNewUrlParser: true,
        useUnifiedTopology: true
    }
)

const db = mongoose.connection;
db.on("error", console.error.bind(console, "connection error: "));
db.once("open", function () {
    console.log("Connected successfully");
});

app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
   next();
  });
app.get("/proyects", async (request, response) => {
    const proyect = await Proyect.find({});
  
    try {
      response.send(proyect);
    } catch (error) {
      response.status(500).send(error);
    }
  });


app.listen(4000, () => {
    console.log("******** SERVER RUNNING **********");
})