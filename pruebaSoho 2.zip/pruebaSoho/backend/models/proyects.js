import mongoose from "mongoose";

const ProyectSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  logo: {
    type: String,
    required: true,
  },
  title: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
});

const Proyect = mongoose.model("Proyect", ProyectSchema);

export default Proyect;