import './App.css';
import { ReactFragment } from "react";
import Navbar from './Components/Navbar';
import { Content } from './Components/Content';
function App() {
  return (
    <>
      <Navbar></Navbar>
      <Content/>
    </>
  );
}

export default App;
