import { useEffect, useState } from "react";

const Proyects = () => {

    const [proyects, SetProyects] = useState([])


    useEffect(() => {
        fetch('http://localhost:4000/proyects')
            .then(response => response.json())
            .then(data => SetProyects(data));

    }, [SetProyects])

    const mapContent = (proyect)=>{
        return {
            name: proyect? proyect.name: "",
            title: proyect? proyect.title: "",
            description: proyect? proyect.description: "",
            logo: proyect? "/assets/"+proyect.logo:"",
            content_image: proyect? "/assets/"+proyect.content_image:"",
        }
    }

    return (
        <>
            { proyects && proyects !==undefined ? 
            ( <>
            <div className="dinners">
                <div className="row">
                    <div className="col-md-6">
                        <img src={mapContent(proyects[0]).content_image} className="w-100" />
                    </div>
                    <div className="col-md-6 p-5">
                        <div className="pt-5">
                            <img src={mapContent(proyects[0]).logo} className="w-30" />
                        </div>
                        <p className="border_dinners mt-3"></p>
                        <h5 className="text-white ">{mapContent(proyects[0]).title} </h5>
                        <p className="text_dinners">{mapContent(proyects[0]).description}</p>
                        <p><span class="material-icons text-white">sell</span> <a className="tag_text">usabilidad</a> <a className="tag_text ms-2">ui</a> <a className="tag_text ms-2">ux</a><a className="tag_text ms-2">test con usuarios</a>
                        </p>
                    </div>
                </div>
            </div>
            <div className="derco">
                <div className="row">
                    <div className="col-md-6 p-5">
                        <div className="pt-5">
                            <img src={mapContent(proyects[1]).logo} className="w-30" />
                        </div>
                        <p className="border_dinners mt-3"></p>
                        <h5 className="text-white ">{mapContent(proyects[1]).title} </h5>
                        <p className="text_dinners">{mapContent(proyects[1]).description}</p>
                        <p><span class="material-icons text-white">sell</span><a className="tag_text ms-2">responsive</a> <a className="tag_text ms-2">ui</a> <a className="tag_text ms-2">ux</a>
                        </p>
                    </div>
                    <div className="col-md-6">
                        <img src={mapContent(proyects[1]).content_image} className="w-100" />
                    </div>
                </div>
            </div>
            <div className="copec">
                <div className="row">
                    <div className="col-md-6">
                        <img src={mapContent(proyects[2]).content_image} className="w-100 mt-5" />
                    </div>
                    <div className="col-md-6 p-5">
                        <div className="pt-5">
                            <img src={mapContent(proyects[2]).logo} className="w-30" />
                        </div>
                        <p className="border_copec mt-3"></p>
                        <h1 >{mapContent(proyects[2]).title}</h1>
                        <p>{mapContent(proyects[2]).description}</p>
                        <p><span class="material-icons text-gray">sell</span> <a className="tag_text_copec">usabilidad</a> <a className="tag_text_copec ms-2">ui</a> <a className="tag_text_copec ms-2">ux</a><a className="tag_text_copec ms-2">test con usuarios</a>
                        </p>
                        <button type="button" class="btn btn-copec  btn-lg text-white">Ver detalles</button>
                    </div>
                </div>
            </div>
            </>
) : null}
        </>
    );
}
export default Proyects