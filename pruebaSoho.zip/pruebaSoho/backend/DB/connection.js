import mongoose from "mongoose";

mongoose.connect(
    "mongodb+srv://juan:1234567890a@cluster0.sxff1.mongodb.net/soho?retryWrites=true&w=majority",
    {
        useNewUrlParser: true,
        useFindAndModify: false,
        useUnifiedTopology: true
      }
)

const db = mongoose.connection;
db.on("error", console.error.bind(console, "connection error: "));
db.once("open", function () {
  console.log("Connected successfully");
});

// const  seedDB = async ()=> {
//     // Connection URL
//     const uri = "mongodb+srv://root:JWJUZNvgoY30kk1B@Cluster0.sxff1.mongodb.net/soho?retryWrites=true&w=majority";
//     const client = new MongoClient(uri, {
//         useNewUrlParser: true,
//         //useUnifiedTopology: true,
//     });
//     try {
//         await client.connect();
//         console.log("Connected correctly to server");
//         const collection = client.db("soho").collection("proyects");

//     } catch (err) {
//         console.log(err.stack);
//     }
// }
// export default seedDB
//JWJUZNvgoY30kk1B