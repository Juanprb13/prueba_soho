import Proyects from "./Proyects"

export const Content = () => {

    return (
        <>

            <div className="stream" >
                <div className="container  p-4">
                    <p className=" text-white"><span class="material-icons text_red me-2">
                        settings_input_antenna
                    </span><b>EN DIRECTO </b> - SOHO está presente en el <b>DIGITAL BANK MONTEVIDEO</b>. "Experiencia de usuario" por Alvaro Añón (SEO de soho).
                        <button className="btn button_home text-white fs-06 btn-lg text_soho  ms-1">Ver evento</button>
                        <button type="button" class="btn btn-outline-soho ms-4 btn-sm">PRÓXIMOS EVENTOS</button>
                    </p>
                </div>
            </div>
            <div className="experience bg-expe">
                <h4 className=" text-white text-center pt-5 ">17 años de experiencia en pos de tu proyecto </h4>
                <p className="border_experience text-center m-auto"></p>
                <p className=" text-white text-center pt-1 text_experience  fs-6">Especializados desde 1996 en usabilidad, experiencia del usuario (UX)y diseño de experiencias de proyectos digitales. Aportamos estrategia e innovación centrada en el usuario y los objetivos de
                    negocio de tu proyecto. Cotrabajando mejoramos tu tasa de conversión, KP´Is, ROI y los resultados de tu actual publicidad PPC (payper click)
                </p>
            </div>
            <div className="container-fluid">
                <div className="row">
                    <div className="col-md-4 text-center p-5 use">
                        <h5 className="text_soho text-center ">Estrategia, usabilidad & UX</h5>
                        <p className="text_experience text_gray">Te ofrecemos una exelente usabilidad y experiencia del usuario en tu proyecto, junto a una visión innovadora</p>
                    </div>
                    <div className="col-md-4 text-center p-5 best">
                        <h5 className="text_soho text-center ">Estrategia, usabilidad & UX</h5>
                        <p className="text_experience text_gray">Te ofrecemos una exelente usabilidad y experiencia del usuario en tu proyecto, junto a una visión innovadora</p>
                    </div>
                    <div className="col-md-4 text-center p-5 measuring">
                        <h5 className="text_soho text-center ">Medición continua de objetivos</h5>
                        <p className="text_experience text_gray">Implementación, testing con usuarios y medición continua son necesarias para garantizar el exíto de tu proyecto </p>
                    </div>
                </div>
            </div>
            <div className="bg-expe">
                <h4 className=" text-white text-center pt-5">Proyectos destacados</h4>
                <p className="border_experience text-center m-auto"></p>
                <p className=" text-white text-center pt-1  p-5 text_gray text_experience fs-6">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                </p>
            </div>
            <Proyects/>
            <footer className="footer m-auto">
                <div className="row">
                    <div className="col-md-4">
                        <p className="text-white p-3">&copy; <b>2017</b> SOHO internet + humana</p>
                    </div>
                    <div className="col-md-4 text-center p-3">
                        <button type="button" class="btn btn-sm text_soho pe-none">Visítanos</button>
                        <button type="button" class="btn btn-sm text_soho pe-none">Escríbenos</button>
                        <button type="button" class="btn btn-sm text_soho pe-none">Llámanos</button>
                    </div>
                    <div className="col-md-4 text-center p-3">
                        <button type="button" class="btn btn-sm facebook pe-none">Facebook</button>
                        <button type="button" class="btn btn-sm twitter pe-none">Twitter</button>
                        <button type="button" class="btn btn-sm facebook pe-none">LinkedIn</button>
                        <button type="button" class="btn btn-sm yt pe-none">YouTube</button>
                    </div>
                </div>
            </footer>
        </>
    )


}