const Navbar = () => {
    return (
        <header class="header">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <a class="navbar-brand" href="#"><img src="/assets/logo-soho.png"  className="w-80 ms-3"/></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse mr-4" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="#inicio">Inicio <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#nosotros">nosotros</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link disabled" href="#">servicios</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link disabled" href="#">casos de exito</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link disabled" href="#">unete al equipo</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link disabled" href="#">contacto</a>
                        </li>
                    </ul>
                </div>
            </nav>
            <div className="text-center mt-6" id="inicio">
                <h1 className=" text-white"> Nos especializamos en </h1>
                <h1 className="text_soho"> interfaces digitales que los usuarios aman </h1>
                <button className="btn button_home text-white fs-06 btn-lg text_soho b-0">HABLEMOS DE TU PROYECTO</button>
            </div>
        </header>
    )
}
export default Navbar